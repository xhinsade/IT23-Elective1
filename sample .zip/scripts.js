document.addEventListener('DOMContentLoaded', function () {
    // Fetch the storybook JSON data
    fetch('storybooks.json')
        .then(response => response.json())
        .then(data => {
            // Display sections dynamically
            const sections = document.getElementById('storybook-sections');
            
            // Function to create the section layout
            function createSection(sectionTitle, sectionData, sectionClass) {
                let sectionHTML = `
                    <section class="py-12 bg-gray-100">
                        <div class="container mx-auto text-center">
                            <h2 class="text-3xl font-bold fun-font mb-8 text-purple-700 animate__animated animate__fadeIn">${sectionTitle}</h2>
                            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                `;

sectionData.forEach(book => {
    sectionHTML += `
        <div class="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition">
            <h3 class="text-xl font-bold mb-2">${book.title}</h3>
            <!-- Image Preview -->
            <img src="${book.image}" alt="${book.title} Preview" class="w-full h-auto mb-4 rounded-lg">
            <p class="text-gray-600 mb-4">${book.description}</p>
            <a href="${book.link}" class="py-2 px-6 rounded-full text-lg font-bold fun-font bg-purple-600 text-white hover:bg-purple-700 transition">Start Adventure</a>
        </div>
    `;
});

                sections.innerHTML += sectionHTML;
            }

            // Create each section
            createSection('Plain Storybooks', data.plainStorybooks, 'plain-storybooks');
            createSection('Read With Me', data.readWithMe, 'read-with-me');
            createSection('Audiobooks', data.audiobooks, 'audiobooks');
            createSection('Video Storybooks', data.videoStorybooks, 'video-storybooks');
        });
});

function createSection(sectionTitle, sectionData, sectionClass) {
    let sectionHTML = `
        <section class="py-12 bg-gray-100">
            <div class="container mx-auto text-center">
                <h2 class="text-3xl font-bold mb-8 text-purple-700">${sectionTitle}</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
    `;

    sectionData.forEach(book => {
        sectionHTML += `
            <div class="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition book-card" data-title="${book.title}" data-image="${book.image}" data-description="${book.description}" data-link="${book.link}">
                <h3 class="text-xl font-bold mb-2">${book.title}</h3>
                <img src="${book.image}" alt="${book.title} Preview" class="w-full h-auto mb-4 rounded-lg">
                <p class="text-gray-600 mb-4">${book.description}</p>
                <a href="${book.link}" class="py-2 px-6 rounded-full text-lg font-bold bg-purple-600 text-white hover:bg-purple-700 transition">Start Adventure</a>
            </div>
        `;
    });

    sections.innerHTML += sectionHTML;
}

// Modal interaction
const modal = document.getElementById('bookModal');
const closeModal = document.getElementById('closeModal');
const modalTitle = document.getElementById('modalTitle');
const modalImage = document.getElementById('modalImage');
const modalDescription = document.getElementById('modalDescription');
const modalLink = document.getElementById('modalLink');

document.addEventListener('click', function (e) {
    if (e.target.classList.contains('book-card')) {
        const book = e.target;
        modalTitle.textContent = book.getAttribute('data-title');
        modalImage.src = book.getAttribute('data-image');
        modalDescription.textContent = book.getAttribute('data-description');
        modalLink.href = book.getAttribute('data-link');
        modal.classList.remove('hidden');
    }
});

closeModal.addEventListener('click', function () {
    modal.classList.add('hidden');
});

document.addEventListener("DOMContentLoaded", () => {
    const pageSound = document.getElementById("page-sound");
    const audioToggleBtn = document.getElementById("audio-toggle-btn");
    let narrationEnabled = true; // Default state: narration is enabled

    // Toggle narration on button click
    audioToggleBtn.addEventListener("click", () => {
        narrationEnabled = !narrationEnabled;
        if (narrationEnabled) {
            audioToggleBtn.textContent = "🔊 Narration";
            pageSound.play(); // Play narration
        } else {
            audioToggleBtn.textContent = "🔇 Narration";
            pageSound.pause(); // Pause narration
        }
    });

    // Example function to update the page
    function updatePage(content) {
        const { imageSrc, text, audioSrc } = content;

        document.getElementById("page-image").src = imageSrc;
        document.getElementById("page-text").textContent = text;
        pageSound.src = audioSrc;

        if (narrationEnabled) {
            pageSound.play();
        }
    }

    // Example content
    const storyPages = [
        {
            imageSrc: "page1.jpg",
            text: "Once upon a time...",
            audioSrc: "page1.mp3",
        },
        {
            imageSrc: "page2.jpg",
            text: "The adventure begins.",
            audioSrc: "page2.mp3",
        },
    ];

    // Example navigation functionality
    let currentPageIndex = 0;

    function showPage(index) {
        if (index >= 0 && index < storyPages.length) {
            updatePage(storyPages[index]);
            document.getElementById("current-page").textContent = index + 1;
        }
    }

    document.getElementById("prev-btn").addEventListener("click", () => {
        if (currentPageIndex > 0) {
            currentPageIndex--;
            showPage(currentPageIndex);
        }
    });

    document.getElementById("next-btn").addEventListener("click", () => {
        if (currentPageIndex < storyPages.length - 1) {
            currentPageIndex++;
            showPage(currentPageIndex);
        }
    });

    // Initial setup
    document.getElementById("total-pages").textContent = storyPages.length;
    showPage(currentPageIndex);
});